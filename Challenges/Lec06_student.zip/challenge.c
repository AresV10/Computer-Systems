#include "challenge.h"

// goal: copy nlines lines from rfile to wfile
// param rfile: name of file to read from
// param wfile: name of file to write to
// param nlines: number lines to copy
// return: error code
//   0 if no issues
//   -1 if error in opening or closing file
//
// TODO: complete the function
//   1. open files. do NOT open wfile in append mode (don't forget error checking)
//   2. copy the n lines (beware nline > number of lines in rfile)
//   3. close files
int copy(const char* rfile, const char* wfile, int nlines)
{
  
  
  return 0;
}
