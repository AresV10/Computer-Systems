#include <stdio.h>

#ifndef CH_HEAD
#define CH_HEAD

// param F: temperature in degrees Fahrenheit
// return: temperature in degrees Celsius
float convert(float F);

#endif