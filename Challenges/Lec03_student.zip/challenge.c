#include "challenge.h"

// Creates a Time struct given the hour, minute, and second
//   param hour: int representing the hour 0-23
//   param min: int representing the minute 0-59
//   param sec: int representing the second 0-59
//   return: a Time struct for the time representing the same time as the integers
// TODO: complete the function
struct Time create_time(int hour, int min, int sec)
{
  return {};
}

// Gets the hour from a Time struct
//   param t: struct representing a time
//   return: an int representing the hour of time t
// TODO: complete the function
int get_hour(struct Time t)
{
  return -1;
}

// Gets the minute from a Time struct
//   param t: struct representing a time
//   return: an int representing the minute of time t
// TODO: complete the function
int get_min(struct Time t)
{
  return -1;
}

// Gets the second from a Time struct
//   param t: struct representing a time
//   return: an int representing the second of time t
// TODO: complete the function
int get_sec(struct Time t)
{
  return -1;
}

// TODO: complete the function
void set_hour(struct Time* t, int hour)
{
}

// TODO: complete the function
void set_min(struct Time* t, int min)
{
}

// TODO: complete the function
void set_sec(struct Time* t, int sec)
{
}

// Creates a Time struct representing the difference between two times
//   param t1: Time struct representing the beginning of interval
//   param t2: Time struct representing the end of interval
//   return: Time struct representing time between t1 and t2
// TODO: complete the function
struct Time elapsed_time(struct Time t1, struct Time t2)
{
  return {};
}
